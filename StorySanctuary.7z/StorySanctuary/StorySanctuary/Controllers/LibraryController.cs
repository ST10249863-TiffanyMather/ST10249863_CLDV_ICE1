﻿using Microsoft.AspNetCore.Mvc;

namespace StorySanctuary.Controllers
{
    public class LibraryController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
